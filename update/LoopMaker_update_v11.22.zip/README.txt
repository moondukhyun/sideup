LoopMaker v11.22 업데이트 꾸러미

사용 방법
1. 이 zip 파일을 우클릭 -> 압축 풀기 (반드시 압축을 푼 폴더에서 실행)
2. LoopMaker 프로그램을 완전히 종료
3. '업데이트_적용하기.bat' 더블클릭 -> 안내에 따라 아무 키나 누르기
   - 기존 파일은 C:\LoopMaker\update_backup_날짜 폴더에 자동 백업됩니다.
4. LoopMaker 를 다시 실행해서 창 제목이 'v11.23' 인지 확인

설치 위치가 다르면 .bat 파일을 메모장으로 열어 위쪽의 두 경로(LOOPMAKER_DIR, SCENEMAKER_DIR)만 고치세요.
되돌리기: 백업 폴더 안의 LoopMaker_v9.py 와 scenemaker 폴더의 파일을 원래 위치로 복사하면 됩니다.

바뀌는 파일
- C:\LoopMaker\LoopMaker_v9.py
- E:\SceneMaker\scenemaker\ : cli.py rain.py scenes.py wetrock.py(새 파일) details.py motion.py glass.py
