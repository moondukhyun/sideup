@echo off
chcp 65001 >nul
setlocal
rem ============================================================
rem  LoopMaker v11.20 업데이트 (백업 후 덮어쓰기)
rem  설치 위치가 다르면 아래 두 줄만 고쳐서 저장하세요.
rem ============================================================
set "LOOPMAKER_DIR=C:\LoopMaker"
set "SCENEMAKER_DIR=E:\SceneMaker\scenemaker"
rem ============================================================
set "SRC=%~dp0"
echo.
echo   LoopMaker v11.20 업데이트
echo   LoopMaker  폴더 : %LOOPMAKER_DIR%
echo   SceneMaker 폴더 : %SCENEMAKER_DIR%
echo.
echo   * LoopMaker 프로그램이 켜져 있으면 먼저 완전히 종료하세요.
echo.
pause

if not exist "%LOOPMAKER_DIR%\LoopMaker_v9.py" (
  echo [오류] %LOOPMAKER_DIR%\LoopMaker_v9.py 를 찾을 수 없어요. 이 파일 위쪽의 LOOPMAKER_DIR 경로를 확인하세요.
  pause
  exit /b 1
)
if not exist "%SCENEMAKER_DIR%\cli.py" (
  echo [오류] %SCENEMAKER_DIR%\cli.py 를 찾을 수 없어요. 이 파일 위쪽의 SCENEMAKER_DIR 경로를 확인하세요.
  pause
  exit /b 1
)
if not exist "%SRC%LoopMaker_v9.py" (
  echo [오류] 압축을 풀지 않고 실행한 것 같아요. zip 파일을 먼저 압축 해제한 뒤 그 폴더에서 실행하세요.
  pause
  exit /b 1
)

for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') do set "TS=%%i"
set "BK=%LOOPMAKER_DIR%\update_backup_%TS%"
mkdir "%BK%\scenemaker"
echo [1/3] 기존 파일 백업: %BK%
copy /Y "%LOOPMAKER_DIR%\LoopMaker_v9.py" "%BK%\" >nul
if errorlevel 1 goto :fail
copy /Y "%SCENEMAKER_DIR%\*.py" "%BK%\scenemaker\" >nul
if errorlevel 1 goto :fail

echo [2/3] LoopMaker_v9.py 교체
copy /Y "%SRC%LoopMaker_v9.py" "%LOOPMAKER_DIR%\LoopMaker_v9.py" >nul
if errorlevel 1 goto :fail

echo [3/3] SceneMaker 파일 7개 교체
copy /Y "%SRC%scenemaker\*.py" "%SCENEMAKER_DIR%\" >nul
if errorlevel 1 goto :fail

echo.
echo  ===== 완료! =====
findstr /C:"v11.20" "%LOOPMAKER_DIR%\LoopMaker_v9.py" >nul && echo  버전 확인: v11.20 적용됨 || echo  [주의] v11.20 표시를 찾지 못했어요.
echo  문제가 생기면 백업 폴더의 파일을 원래 위치로 되돌리면 됩니다:
echo    %BK%
echo.
pause
exit /b 0

:fail
echo.
echo [오류] 파일 복사에 실패했어요. LoopMaker/SceneMaker 가 켜져 있거나 폴더 권한 문제일 수 있어요.
echo        백업은 여기에 있어요: %BK%
pause
exit /b 1
